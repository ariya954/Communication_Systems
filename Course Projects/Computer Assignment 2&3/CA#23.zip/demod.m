function output = demod(f_osc1, f_osc2, fs, W1, W2, t, input)
    N = length(input);
    
    osc1= 2*cos(2*pi*f_osc1*t);
    osc2 = 2*cos(2*pi*f_osc2*t);
    
    lpf1 = zeros(1, N);
    range1 = (fs/2-W1)*N/fs:(fs/2+W1)*N/fs;
    lpf1(range1) = 1;
    
    lpf2 = zeros(1, N);
    range2 = (fs/2-W2)*N/fs:(fs/2+W2)*N/fs;
    lpf2(range2) = 1;
        
    shifted_signal = abs(fftshift(fft(input .* osc1)));
    filtered_signal = ifft(shifted_signal .* lpf1);
    final_signal = abs(fft(filtered_signal .* osc2));
    
    output = final_signal .* lpf2;
end