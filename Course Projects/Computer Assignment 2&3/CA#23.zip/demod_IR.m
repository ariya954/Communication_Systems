function output = demod_IR(f_osc1, f_osc2, fs, W1, W2, f, t, input)
    N = length(input);
    
    osc1_cos = 2*cos(2*pi*f_osc1*t);
    osc1_sin = 2*sin(2*pi*f_osc1*t);
    osc2 = 2*cos(2*pi*f_osc2*t);
    
    lpf1 = zeros(1, N);
    range1 = (fs/2-W1)*N/fs:(fs/2+W1)*N/fs;
    lpf1(range1) = 1;
    
    lpf2 = zeros(1, N);
    range2 = (fs/2-W2)*N/fs:(fs/2+W2)*N/fs;
    lpf2(range2) = 1;
    
    shifted_signal_cos = fftshift(fft(input .* osc1_cos));
    shifted_signal_sin = fftshift(fft(input .* osc1_sin));
    
    Hilbert = -(1i)*sign(f);
    
    filtered_signal_cos = shifted_signal_cos .* lpf1;
    filtered_signal_sin = shifted_signal_sin .* lpf1 .* Hilbert;
    
    image_rejected = ifft(filtered_signal_cos - filtered_signal_sin);
    final_signal = abs(fft(image_rejected .* osc2));
    
    output = final_signal .* lpf2;
    
end