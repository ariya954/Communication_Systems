function DSB_modulated_signal = DSB_modulator(Ac, Xm, fc, t)

DSB_modulated_signal = Ac * Xm .* cos(2 * pi * fc .* t);

end