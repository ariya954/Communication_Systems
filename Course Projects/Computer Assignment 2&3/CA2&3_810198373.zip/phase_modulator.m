function phase_modulated_signal = phase_modulator(m, Ac, fc, kp, fs)

Ts = 1/fs;
t = 0:Ts:0.2-Ts;

phase_modulated_signal = Ac * cos((2 * pi * fc .* t) + (kp * m));

end