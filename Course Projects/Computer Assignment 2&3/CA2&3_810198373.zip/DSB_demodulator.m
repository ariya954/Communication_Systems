function [none_filtered_sychronous_detector, massage_signal] = DSB_demodulator(Ac, Xc, fc, fs, massage_signal_band_width, t)

    none_filtered_sychronous_detector = Xc .* (2 * Ac * cos(2 * pi * fc .* t));
    massage_signal = lowpass(none_filtered_sychronous_detector, massage_signal_band_width, fs);

end