function frequency_modulated_signal = frequency_modulator(m, Ac, fc, kf, fs)

Ts = 1/fs;

integral_of_massage_signal = (Ts * sum(m)) / 2;

frequency_modulated_signal = phase_modulator((2*pi*kf*integral_of_massage_signal), Ac, fc, 1, fs);

end