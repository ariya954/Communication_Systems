function out = convolution(x, y)

size_x = length(x);
size_y = length(y);
length_output = min([size_x, size_y]);

Z = zeros(1, length_output);

X = fftshift(fft(x));
Y = fftshift(fft(y));

for i = 1 : length_output
    Z(i) = X(i) * Y(i);
end
out = ifft(ifftshift(Z));

end