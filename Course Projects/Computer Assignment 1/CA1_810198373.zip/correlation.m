function corr = correlation(x, y)

size_x = length(x);
size_y = length(y);
length_output = min([size_x, size_y]);

corr_fourier_transform = zeros(1, length_output);

X = fftshift(fft(x));
Y = fftshift(fft(y));

for i = 1 : length_output
    corr_fourier_transform(i) = Y(i) * conj(X(i));
end

corr = ifftshift(ifft(corr_fourier_transform));

end

